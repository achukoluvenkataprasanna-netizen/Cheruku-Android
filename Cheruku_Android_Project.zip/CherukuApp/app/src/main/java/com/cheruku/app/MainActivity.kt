package com.cheruku.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var rec: SpeechRecognizer? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this); setContentView(web)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            allowFileAccess = false; allowContentAccess = false
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(r.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) =
                r.url.host != "appassets.androidplatform.net" // never navigate the bridge page away
        }
        web.addJavascriptInterface(Bridge(), "Cheruku")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        Hub.sink = { t, x ->
            runOnUiThread {
                web.evaluateJavascript("window.onCheruku&&window.onCheruku(${JSONObject.quote(t)},${JSONObject.quote(x)})", null)
            }
        }
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }

        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        ActivityCompat.requestPermissions(this, perms.toTypedArray(), 1)
    }

    private fun listen() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Hub.emit("status", "Microphone permission needed"); return
        }
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { Hub.emit("heard", it) }
                }
                override fun onError(e: Int) { Hub.emit("status", "Didn't catch that") }
                override fun onReadyForSpeech(p: Bundle?) { Hub.emit("status", "Listening...") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
        }
    }

    inner class Bridge {
        @JavascriptInterface fun hasKey() = Prefs.key(this@MainActivity).isNotBlank()
        @JavascriptInterface fun saveSettings(key: String, model: String) {
            if (key.isNotBlank()) Prefs.setKey(this@MainActivity, key)
            Prefs.setModel(this@MainActivity, model)
        }
        @JavascriptInterface fun send(text: String) {
            ContextCompat.startForegroundService(this@MainActivity,
                Intent(this@MainActivity, AgentService::class.java).putExtra("goal", text.take(2000)))
        }
        @JavascriptInterface fun a11yEnabled() = CherukuAccessibilityService.instance != null
        @JavascriptInterface fun openA11ySettings() { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        @JavascriptInterface fun abort() { Agent.cancel(); tts?.stop() }
        @JavascriptInterface fun listen() { runOnUiThread { this@MainActivity.listen() } }
        @JavascriptInterface fun speak(t: String) {
            tts?.speak(t.replace(Regex("[*#_`>]"), ""), TextToSpeech.QUEUE_FLUSH, null, "c")
        }
        @JavascriptInterface fun device(cmd: String): String = DeviceController.quick(this@MainActivity, cmd)
    }

    override fun onDestroy() {
        Hub.sink = null; rec?.destroy(); tts?.shutdown(); super.onDestroy()
    }
}
