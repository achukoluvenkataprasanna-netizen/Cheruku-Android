package com.cheruku.app

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object Prefs {
    private fun sp(c: Context) = EncryptedSharedPreferences.create(
        c, "cheruku_secure",
        MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    fun key(c: Context): String = sp(c).getString("key", "") ?: ""
    fun setKey(c: Context, v: String) = sp(c).edit().putString("key", v.trim()).apply()
    fun model(c: Context): String = sp(c).getString("model", "claude-sonnet-5-5") ?: "claude-sonnet-5-5"
    fun setModel(c: Context, v: String) { if (v.startsWith("claude")) sp(c).edit().putString("model", v.trim()).apply() }
}

object Hub {
    @Volatile var sink: ((String, String) -> Unit)? = null
    fun emit(type: String, text: String) { sink?.invoke(type, text) }
}
