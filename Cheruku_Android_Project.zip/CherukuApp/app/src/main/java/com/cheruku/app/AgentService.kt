package com.cheruku.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.ServiceCompat

class AgentService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val goal = i?.getStringExtra("goal") ?: run { stopSelf(); return START_NOT_STICKY }
        val ch = "cheruku_agent"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(ch, "Cheruku agent", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getBroadcast(this, 0, Intent(this, StopReceiver::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Cheruku is working")
            .setContentText(goal.take(60))
            .addAction(Notification.Action.Builder(null, "STOP", stop).build())
            .setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        Thread {
            Agent.run(applicationContext, goal)
            if (!Agent.running) stopSelf()
        }.start()
        return START_NOT_STICKY
    }
}

class StopReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context?, i: Intent?) {
        Agent.cancel()
        CherukuAccessibilityService.instance?.hideStop()
    }
}
