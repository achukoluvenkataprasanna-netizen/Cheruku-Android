package com.cheruku.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class CherukuAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: CherukuAccessibilityService? = null }

    private var nodes: List<AccessibilityNodeInfo> = emptyList()
    private val main = Handler(Looper.getMainLooper())
    private var stopView: View? = null

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------- Seeing the screen ----------
    fun snapshot(): String {
        val root = rootInActiveWindow ?: return "[no active window]"
        val list = mutableListOf<AccessibilityNodeInfo>()
        val sb = StringBuilder("app=${root.packageName}\n")
        fun walk(n: AccessibilityNodeInfo) {
            if (list.size >= 120) return
            val t = n.text?.toString()?.take(80)
            val d = n.contentDescription?.toString()?.take(80)
            val useful = n.isClickable || n.isEditable || n.isScrollable || !t.isNullOrBlank() || !d.isNullOrBlank()
            if (n.isVisibleToUser && useful) {
                val r = Rect(); n.getBoundsInScreen(r)
                val flags = buildString {
                    if (n.isClickable) append("tap ")
                    if (n.isEditable) append(if (n.isPassword) "PASSWORD-FIELD " else "input ")
                    if (n.isScrollable) append("scroll ")
                    if (n.isChecked) append("checked ")
                }
                val txt = if (n.isPassword) "" else (t ?: "")
                sb.append("[${list.size}] ${flags}\"$txt\" ${d ?: ""} @${r.centerX()},${r.centerY()}\n")
                list.add(n)
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        nodes = list
        return sb.toString()
    }

    fun labelOf(i: Int): String {
        val n = nodes.getOrNull(i) ?: return ""
        return (n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")
    }

    // ---------- Acting ----------
    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect(); n.getBoundsInScreen(r)
        return tap(r.centerX().toFloat(), r.centerY().toFloat())
    }

    fun click(i: Int): String {
        val n = nodes.getOrNull(i) ?: return "No element [$i]. Call read_screen first."
        return if (clickNode(n)) "Tapped [$i]." else "Tap failed."
    }

    fun clickText(text: String): String {
        val n = rootInActiveWindow?.findAccessibilityNodeInfosByText(text)?.firstOrNull { it.isVisibleToUser }
            ?: return "Nothing on screen matches '$text'."
        return if (clickNode(n)) "Tapped '$text'." else "Tap failed."
    }

    private fun gesture(path: Path, dur: Long): Boolean {
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
        val latch = CountDownLatch(1); var ok = false
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        latch.await(3, TimeUnit.SECONDS)
        return ok
    }

    fun tap(x: Float, y: Float): Boolean = gesture(Path().apply { moveTo(x, y) }, 60)

    fun type(text: String, index: Int?, submit: Boolean): String {
        val n = index?.let { nodes.getOrNull(it) }
            ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: nodes.firstOrNull { it.isEditable }
            ?: return "No text field found."
        if (n.isPassword) return "Refused: this is a password field. Ask the user to type it themselves."
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        val ok = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        if (ok && submit && Build.VERSION.SDK_INT >= 30) n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        return if (ok) "Typed." else "Could not type there."
    }

    fun scroll(dir: String): String {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
        val p = Path()
        when (dir) {
            "down" -> { p.moveTo(w / 2, h * 0.7f); p.lineTo(w / 2, h * 0.3f) }
            "up" -> { p.moveTo(w / 2, h * 0.3f); p.lineTo(w / 2, h * 0.7f) }
            "left" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            "right" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            else -> return "direction must be up, down, left or right."
        }
        return if (gesture(p, 350)) "Scrolled $dir." else "Scroll failed."
    }

    fun press(key: String): String {
        val a = when (key) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "lock_screen" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return "Not supported on this Android version."
            else -> return "Unknown key '$key'."
        }
        return if (performGlobalAction(a)) "Pressed $key." else "Press failed."
    }

    // ---------- On-screen safety UI (no extra permission: accessibility overlay) ----------
    private fun lp(gravity: Int, y: Int = 0, touch: Boolean = true) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { this.gravity = gravity; this.y = y }

    fun showStop() = main.post {
        if (stopView != null) return@post
        val b = Button(this).apply {
            text = "■ STOP"; setTextColor(Color.WHITE); setBackgroundColor(0xDDF43F5E.toInt())
            setOnClickListener { Agent.cancel(); hideStop() }
        }
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(b, lp(Gravity.TOP or Gravity.END, 220))
        stopView = b
    }

    fun hideStop() = main.post {
        stopView?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {} }
        stopView = null
    }

    /** Blocks the calling (agent) thread until the user taps Allow or Deny. Denies after 60 s. */
    fun askConfirm(question: String): Boolean {
        val latch = CountDownLatch(1); var allowed = false
        var card: View? = null
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        main.post {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(48, 40, 48, 32); setBackgroundColor(0xF2131B2E.toInt())
            }
            box.addView(TextView(this).apply { text = "Cheruku asks"; setTextColor(0xFF06B6D4.toInt()); textSize = 13f })
            box.addView(TextView(this).apply { text = question; setTextColor(Color.WHITE); textSize = 17f; setPadding(0, 12, 0, 24) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(Button(this).apply { text = "Deny"; setOnClickListener { latch.countDown() } })
            row.addView(Button(this).apply { text = "Allow"; setOnClickListener { allowed = true; latch.countDown() } })
            box.addView(row)
            wm.addView(box, lp(Gravity.CENTER)); card = box
        }
        latch.await(60, TimeUnit.SECONDS)
        main.post { card?.let { try { wm.removeView(it) } catch (_: Exception) {} } }
        return allowed
    }
}
