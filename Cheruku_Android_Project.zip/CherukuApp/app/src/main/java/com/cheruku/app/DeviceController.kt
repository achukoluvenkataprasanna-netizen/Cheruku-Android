package com.cheruku.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent

object DeviceController {
    private var torchOn = false

    // Launch from the accessibility service's context when possible: it is allowed to start
    // activities while another app is in front.
    private fun launch(ctx: Context, i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        (CherukuAccessibilityService.instance ?: ctx).startActivity(i); true
    } catch (e: Exception) { false }

    fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val q = name.lowercase().trim()
        val m = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "No installed app matches '$name'."
        val i = pm.getLaunchIntentForPackage(m.activityInfo.packageName) ?: return "Cannot launch that app."
        return if (launch(ctx, i)) "Opened ${m.loadLabel(pm)}." else "Android blocked the launch."
    }

    fun openUrl(ctx: Context, url: String): String {
        if (!url.startsWith("https://") && !url.startsWith("http://")) return "Only http(s) links are allowed."
        return if (launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))) "Opened link." else "Could not open link."
    }

    fun openSettings(ctx: Context, page: String): String {
        val action = when (page.lowercase()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return if (launch(ctx, Intent(action))) "Opened $page settings." else "Could not open settings."
    }

    fun flashlight(ctx: Context, on: Boolean): String = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        cm.setTorchMode(id, on); torchOn = on
        if (on) "Flashlight on." else "Flashlight off."
    } catch (e: Exception) { "No flashlight available." }

    fun setVolume(ctx: Context, percent: Int): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, max * percent.coerceIn(0, 100) / 100, AudioManager.FLAG_SHOW_UI)
        return "Media volume set to $percent%."
    }

    fun media(ctx: Context, action: String): String {
        val code = when (action) {
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "Sent media key: $action."
    }

    fun setAlarm(ctx: Context, hour: Int, minute: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute).putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(ctx, i)) "Alarm set for %02d:%02d.".format(hour, minute) else "Could not set alarm."
    }

    fun setTimer(ctx: Context, seconds: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(ctx, i)) "Timer set for $seconds seconds." else "Could not set timer."
    }

    fun call(ctx: Context, number: String): String {
        val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val i = Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))
        return if (launch(ctx, i)) (if (granted) "Calling $number." else "Dialer opened with $number; user must press call.") else "Could not start call."
    }

    fun composeSms(ctx: Context, number: String, body: String): String {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", body)
        return if (launch(ctx, i)) "Message drafted. It is NOT sent until the Send button is tapped." else "Could not open Messages."
    }

    // Quick buttons on the Cheruku home screen
    fun quick(ctx: Context, cmd: String): String = when (cmd) {
        "flashlight" -> flashlight(ctx, !torchOn)
        "wifi" -> openSettings(ctx, "wifi")
        "dnd" -> openSettings(ctx, "sound")
        else -> "Unknown control."
    }
}
