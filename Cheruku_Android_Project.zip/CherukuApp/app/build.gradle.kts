plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.cheruku.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.cheruku.app"; minSdk = 26; targetSdk = 34
        versionCode = 1; versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.webkit:webkit:1.11.0")
}

// Downloads the three UI libraries once so the WebView never runs remote scripts
// (a remote script on the page could otherwise reach the device-control bridge).
val vendorJs = tasks.register("vendorJs") {
    val dir = file("src/main/assets/js")
    outputs.dir(dir)
    doLast {
        dir.mkdirs()
        mapOf(
            "tailwind.js" to "https://cdn.tailwindcss.com/3.4.17",
            "lucide.js" to "https://cdn.jsdelivr.net/npm/lucide@0.460.0/dist/umd/lucide.min.js",
            "marked.js" to "https://cdn.jsdelivr.net/npm/marked@12.0.2/marked.min.js"
        ).forEach { (name, url) ->
            val f = File(dir, name)
            if (!f.exists()) java.net.URL(url).openStream().use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        }
    }
}
tasks.named("preBuild") { dependsOn(vendorJs) }
