# Cheruku for Android

Your Cheruku UI inside a native Android app, with a Claude-powered agent that can see and operate the phone.

## Build (needs Android Studio + internet for the first build)
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync. The first build downloads
   Tailwind, Lucide and Marked into `app/src/main/assets/js/` (task `vendorJs`).
2. Plug in your phone (USB debugging on) and press Run, or Build > Build APK(s).

## First run
1. Open Cheruku > Settings, paste your Anthropic API key (stored encrypted on the device), and set Model
   to `claude-sonnet-5-5` (or any `claude-*` model).
2. Android Settings > Accessibility > Cheruku > turn on. This is the permission that lets it tap, type and scroll.
   If Android says "restricted setting": App info > three dots > Allow restricted settings.
3. Ask: "open YouTube and search for lo-fi music", "set an alarm for 6:30", "turn on the flashlight".

## Safety built in
- Red STOP button floats on screen while Cheruku acts; STOP is also in the notification and the in-app ABORT.
- Allow/Deny card (shown over any app) before calls, and before tapping Send/Pay/Buy/Delete/Post-type buttons.
- Refuses to type into password fields. Text on screen is treated as data, never as instructions.
- 25-step cap per task. Messages are only drafted; nothing sends without a confirmed tap.
- The WebView runs only bundled scripts (CSP), so web content cannot reach the device bridge.

## Known limits
- Android only. iOS does not allow this kind of control.
- Google Play restricts accessibility apps for general automation: sideload the APK.
- Health numbers, weather and news widgets in the prototype are still placeholders.
- Apps that block accessibility (some banking apps, FLAG_SECURE screens) will look empty to Cheruku.
- Reel abilities: not added yet (the reel could not be read).
